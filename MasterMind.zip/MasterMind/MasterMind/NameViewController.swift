import UIKit

var classement = [userData.integer(forKey:"c0"),userData.integer(forKey:"c1"),userData.integer(forKey:"c2")]
var classement_nom = [userData.string(forKey:"nc0"),userData.string(forKey:"nc1"),userData.string(forKey:"nc2")]
var r = 0
var w = ""

class NameViewController: UIViewController {

    @IBOutlet weak var ChampTexte: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func dateDuJour() -> String {
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM.yyyy"
        let result = formatter.string(from: date)
        return result
    }
    

    @IBAction func Valider(_ sender: UIButton) {
        if(ChampTexte.text != ""){
            if ( monIndex == 0 ) {
                userData.set(ChampTexte.text,forKey: "n1")
                userData.set(dateDuJour(),forKey: "t1")
                userData.set(s,forKey: "s1")
                if(userData.integer(forKey: "s1")>=classement[2]){
                    classement[2] = userData.integer(forKey: "s1")
                    classement_nom[2] = userData.string(forKey: "n1")
                }
                if(perdu){ userData.set(0,forKey: "s1") }
            }
            if ( monIndex == 1 ) {
                userData.set(ChampTexte.text,forKey: "n2")
                userData.set(dateDuJour(),forKey: "t2")
                userData.set(s,forKey: "s2")
                if(userData.integer(forKey: "s2")>=classement[2]){
                    classement[2] = userData.integer(forKey: "s2")
                    classement_nom[2] = userData.string(forKey: "n2")
                }
                if(perdu){ userData.set(0,forKey: "s2") }
            }
            if ( monIndex == 2 ) {
                userData.set(ChampTexte.text,forKey: "n3")
                userData.set(dateDuJour(),forKey: "t3")
                userData.set(s,forKey: "s3")
                if(userData.integer(forKey: "s3")>=classement[2]){
                    classement[2] = userData.integer(forKey: "s3")
                    classement_nom[2] = userData.string(forKey: "n3")
                }
                if(perdu){ userData.set(0,forKey: "s3") }
            }
            
            for i in 0...2 {
                for j in 0...2 {
                    if(classement[i] >= classement[j]){
                        r = classement[i]
                        classement[i] = classement[j]
                        classement[j] = r
                        
                        w = classement_nom[i]!
                        classement_nom[i] = classement_nom[j]
                        classement_nom[j] = w
                    }
                }
            }
            userData.set(classement[0],forKey:"c0")
            userData.set(classement[1],forKey:"c1")
            userData.set(classement[2],forKey:"c2")
            
            userData.set(classement_nom[0],forKey:"nc0")
            userData.set(classement_nom[1],forKey:"nc1")
            userData.set(classement_nom[2],forKey:"nc2")
            
        }
    }
    
}
