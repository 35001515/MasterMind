import UIKit

let userData = UserDefaults.standard
var perdu = false
var s = 0

class SecondViewController: UIViewController {

    @IBOutlet weak var C1: UIButton! ; @IBOutlet weak var C2: UIButton!
    @IBOutlet weak var C3: UIButton! ; @IBOutlet weak var C4: UIButton!

    @IBOutlet weak var Un: UIButton! ; @IBOutlet weak var Deux: UIButton!
    @IBOutlet weak var Trois: UIButton! ; @IBOutlet weak var Quatre: UIButton!
    
    @IBOutlet weak var Cinq: UIButton! ; @IBOutlet weak var Six: UIButton!
    @IBOutlet weak var Sept: UIButton! ; @IBOutlet weak var Huit: UIButton!
    
    @IBOutlet weak var Neuf: UIButton! ; @IBOutlet weak var Dix: UIButton!
    @IBOutlet weak var Onze: UIButton! ; @IBOutlet weak var Douze: UIButton!
    
    @IBOutlet weak var Treize: UIButton! ; @IBOutlet weak var Quatorze: UIButton!
    @IBOutlet weak var Quinze: UIButton! ; @IBOutlet weak var Seize: UIButton!
    
    @IBOutlet weak var DixSept: UIButton! ; @IBOutlet weak var DixHuit: UIButton!
    @IBOutlet weak var DixNeuf: UIButton! ; @IBOutlet weak var Vingt: UIButton!
    
    @IBOutlet weak var VingtEtUn: UIButton! ; @IBOutlet weak var VingtDeux: UIButton!
    @IBOutlet weak var VingtTrois: UIButton! ; @IBOutlet weak var VingtQuatre: UIButton!
    
    @IBOutlet weak var VingtCinq: UIButton! ; @IBOutlet weak var VingtSix: UIButton!
    @IBOutlet weak var VingtSept: UIButton! ; @IBOutlet weak var VingtHuit: UIButton!
    
    @IBOutlet weak var VingtNeuf: UIButton! ; @IBOutlet weak var Trente: UIButton!
    @IBOutlet weak var TrenteEtUn: UIButton! ; @IBOutlet weak var TrenteDeux: UIButton!
    
    @IBOutlet weak var TrenteTrois: UIButton! ; @IBOutlet weak var TrenteQuatre: UIButton!
    @IBOutlet weak var TrenteCinq: UIButton! ; @IBOutlet weak var TrenteSix: UIButton!
    
    @IBOutlet weak var TrenteSept: UIButton! ; @IBOutlet weak var TrenteHuit: UIButton!
    @IBOutlet weak var TrenteNeuf: UIButton! ; @IBOutlet weak var Quarante: UIButton!
    
    @IBOutlet weak var QuaranteEtUn: UIButton! ; @IBOutlet weak var QuaranteDeux: UIButton!
    @IBOutlet weak var QuaranteTrois: UIButton! ; @IBOutlet weak var QuaranteQuatre: UIButton!
    
    @IBOutlet weak var QuaranteCinq: UIButton! ; @IBOutlet weak var QuaranteSix: UIButton!
    @IBOutlet weak var QuaranteSept: UIButton! ; @IBOutlet weak var QuaranteHuit: UIButton!
    
    @IBOutlet weak var Score: UILabel!
    
    var combinaison_tag = [UIButton]()
    var correct = 0
    
    var boutons = [UIButton]()
    var cran = 0
    var tentative = 0
    
    @IBOutlet weak var IndiceUn: UIButton! ; @IBOutlet weak var IndiceDeux: UIButton!
    @IBOutlet weak var IndiceTrois: UIButton! ; @IBOutlet weak var IndiceQuatre: UIButton!
    
    @IBOutlet weak var IndiceCinq: UIButton! ; @IBOutlet weak var IndiceSix: UIButton!
    @IBOutlet weak var IndiceSept: UIButton! ; @IBOutlet weak var IndiceHuit: UIButton!
    
    @IBOutlet weak var IndiceNeuf: UIButton! ; @IBOutlet weak var IndiceDix: UIButton!
    @IBOutlet weak var IndiceOnze: UIButton! ; @IBOutlet weak var IndiceDouze: UIButton!
    
    @IBOutlet weak var IndiceTreize: UIButton! ; @IBOutlet weak var IndiceQuatorze: UIButton!
    @IBOutlet weak var IndiceQuinze: UIButton! ; @IBOutlet weak var IndiceSeize: UIButton!
    
    @IBOutlet weak var IndiceDixSept: UIButton! ; @IBOutlet weak var IndiceDixHuit: UIButton!
    @IBOutlet weak var IndiceDixNeuf: UIButton! ; @IBOutlet weak var IndiceVingt: UIButton!
    
    @IBOutlet weak var IndiceVingtEtUn: UIButton! ; @IBOutlet weak var IndiceVingtDeux: UIButton!
    @IBOutlet weak var IndiceVingtTrois: UIButton! ; @IBOutlet weak var IndiceVingtQuatre: UIButton!
    
    @IBOutlet weak var IndiceVingtCinq: UIButton! ; @IBOutlet weak var IndiceVingtSix: UIButton!
    @IBOutlet weak var IndiceVingtSept: UIButton! ; @IBOutlet weak var IndiceVingtHuit: UIButton!
    
    @IBOutlet weak var IndiceVingtNeuf: UIButton! ; @IBOutlet weak var IndiceTrente: UIButton!
    @IBOutlet weak var IndiceTrenteEtUn: UIButton! ; @IBOutlet weak var IndiceTrenteDeux: UIButton!
    
    @IBOutlet weak var IndiceTrenteTrois: UIButton! ; @IBOutlet weak var IndiceTrenteQuatre: UIButton!
    @IBOutlet weak var IndiceTrenteCinq: UIButton! ; @IBOutlet weak var IndiceTrenteSix: UIButton!
    
    @IBOutlet weak var IndiceTrenteSept: UIButton! ; @IBOutlet weak var IndiceTrenteHuit: UIButton!
    @IBOutlet weak var IndiceTrenteNeuf: UIButton! ; @IBOutlet weak var IndiceQuarante: UIButton!
    
    @IBOutlet weak var IndiceQuaranteEtUn: UIButton! ; @IBOutlet weak var IndiceQuaranteDeux: UIButton!
    @IBOutlet weak var IndiceQuaranteTrois: UIButton! ; @IBOutlet weak var IndiceQuaranteQuatre: UIButton!
    
    var indices = [UIButton]()

    var verif_i = [String]()
    var verif_j = [String]()
    
    var bien_places = 0
    var mal_places = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        combinaison_tag = [C1,C2,C3,C4]
        boutons = [Un,Deux,Trois,Quatre,Cinq,Six,Sept,Huit,Neuf,Dix,Onze,Douze,Treize,Quatorze,Quinze,Seize,DixSept,DixHuit,DixNeuf,Vingt,VingtEtUn,VingtDeux,VingtTrois,VingtQuatre,VingtCinq,VingtSix,VingtSept,VingtHuit,VingtNeuf,Trente,TrenteEtUn,TrenteDeux,TrenteTrois,TrenteQuatre,TrenteCinq,TrenteSix,TrenteSept,TrenteHuit,TrenteNeuf,Quarante,QuaranteEtUn,QuaranteDeux,QuaranteTrois,QuaranteQuatre,QuaranteCinq,QuaranteSix,QuaranteSept,QuaranteHuit]
        indices = [IndiceUn,IndiceDeux,IndiceTrois,IndiceQuatre,IndiceCinq,IndiceSix,IndiceSept,IndiceHuit,IndiceNeuf,IndiceDix,IndiceOnze,IndiceDouze,IndiceTreize,IndiceQuatorze,IndiceQuinze,IndiceSeize,IndiceDixSept,IndiceDixHuit,IndiceDixNeuf,IndiceVingt,IndiceVingtEtUn,IndiceVingtDeux,IndiceVingtTrois,IndiceVingtQuatre,IndiceVingtCinq,IndiceVingtSix,IndiceVingtSept,IndiceVingtHuit,IndiceVingtNeuf,IndiceTrente,IndiceTrenteEtUn,IndiceTrenteDeux,IndiceTrenteTrois,IndiceTrenteQuatre,IndiceTrenteCinq,IndiceTrenteSix,IndiceTrenteSept,IndiceTrenteHuit,IndiceTrenteNeuf,IndiceQuarante,IndiceQuaranteEtUn,IndiceQuaranteDeux,IndiceQuaranteTrois,IndiceQuaranteQuatre]
        verif_i = ["","","",""]
        verif_j = ["","","",""]
        Relance()
        if(myIndex == -1){ s = userData.integer(forKey: "s") }
        if(myIndex == 0){ s = userData.integer(forKey: "s1") }
        if(myIndex == 1){ s = userData.integer(forKey: "s2") }
        if(myIndex == 2){ s = userData.integer(forKey: "s3") }
        Score.text = "SCORE : " + String(s)
    }
    
    func Relance(){
        for i in 0...3 {
            combinaison_tag[i].tag = Int(arc4random_uniform(6))
            if( combinaison_tag[i].tag == 0){ combinaison_tag[i].backgroundColor = UIColor.red }
            if( combinaison_tag[i].tag == 1){ combinaison_tag[i].backgroundColor = UIColor.green }
            if( combinaison_tag[i].tag == 2){ combinaison_tag[i].backgroundColor = UIColor.blue }
            if( combinaison_tag[i].tag == 3){ combinaison_tag[i].backgroundColor = UIColor(red:255/255, green: 255/255, blue: 0, alpha: 1) }
            if( combinaison_tag[i].tag == 4){ combinaison_tag[i].backgroundColor = UIColor(red:255/255, green: 0/255, blue: 200/255, alpha: 1) }
            if( combinaison_tag[i].tag == 5){ combinaison_tag[i].backgroundColor = UIColor.black }
        }
        for i in 0...47 {
            boutons[i].backgroundColor = UIColor(red:120/255, green: 120/255, blue: 120/255, alpha: 1)
            boutons[i].tag = -1
            if(i<4){ boutons[i].isEnabled = true }
            else { boutons[i].isEnabled = false ; boutons[i].isHidden = true }
        }
        for i in 0...43 {
            indices[i].backgroundColor = UIColor(red:120/255, green: 120/255, blue: 120/255, alpha: 1)
            indices[i].isHidden = true
        }
    }
    
    @IBAction func Validation(_ sender: UIButton) {
        if(boutons[cran].tag != -1 && boutons[cran+1].tag != -1 && boutons[cran+2].tag != -1 && boutons[cran+3].tag != -1){
            if(boutons[cran].tag == C1.tag){ correct = correct + 1 }
            if(boutons[cran+1].tag == C2.tag){ correct = correct + 1 }
            if(boutons[cran+2].tag == C3.tag){ correct = correct + 1 }
            if(boutons[cran+3].tag == C4.tag){ correct = correct + 1 }
            if(correct == 4){
                s = s + 12 - tentative
                Score.text = "SCORE : " + String(s)
                cran = 0
                Relance()
            }
            else {
                for i in 0...3{
                    if (boutons[i+cran].tag == combinaison_tag[i].tag) {
                        bien_places = bien_places + 1
                        verif_j[i] = "X"
                        verif_i[i] = "X"
                    }
                }
                
                for i in 0...3{
                    for j in 0...3{
                        if ((combinaison_tag[i].tag == boutons[j+cran].tag) && verif_i[i] != "X" && verif_j[j] != "X") {
                            mal_places = mal_places + 1
                            verif_i[i] = "X"
                            verif_j[j] = "X"
                        }
                    }
                }
                
                verif_i = ["","","",""]
                verif_j = ["","","",""]
                
                if(bien_places != 0){
                    for k in 0...bien_places-1{
                        if(cran<44){
                            indices[k+cran].backgroundColor = UIColor(red:0, green: 255/255, blue: 255/255, alpha: 1)
                            indices[k+cran].isHidden = false
                        }
                    }
                }
                
                if(mal_places != 0){
                    for l in 0...mal_places-1{
                        if(cran<44){
                            indices[l+bien_places+cran].backgroundColor = UIColor(red:90/255, green: 40/255, blue: 0, alpha: 1)
                            indices[l+bien_places+cran].isHidden = false
                        }
                    }
                }
                
                
                tentative = tentative + 1
                boutons[cran].isEnabled = false; boutons[cran+1].isEnabled = false
                boutons[cran+2].isEnabled = false; boutons[cran+3].isEnabled = false
                cran = cran + 4
                if(cran<48){
                    boutons[cran].isEnabled = true; boutons[cran].isHidden = false
                    boutons[cran+1].isEnabled = true; boutons[cran+1].isHidden = false
                    boutons[cran+2].isEnabled = true; boutons[cran+2].isHidden = false
                    boutons[cran+3].isEnabled = true; boutons[cran+3].isHidden = false
                }
                if(cran == 48){
                    tentative = 0
                    cran = 0
                    perdu = true
                    performSegue(withIdentifier: "quitter", sender: self)
                }
            }
            correct = 0
            bien_places = 0
            mal_places = 0
        }
    }
    
    @IBAction func Selection(_ sender: UIButton) {
        sender.tag = sender.tag + 1
        if( sender.tag == 0 || sender.tag == 6){ sender.tag = 0 ; sender.backgroundColor = UIColor.red }
        if( sender.tag == 1){ sender.backgroundColor = UIColor.green }
        if( sender.tag == 2){ sender.backgroundColor = UIColor.blue }
        if( sender.tag == 3){ sender.backgroundColor = UIColor(red:255/255, green: 255/255, blue: 0, alpha: 1) }
        if( sender.tag == 4){ sender.backgroundColor = UIColor(red:255/255, green: 0/255, blue: 200/255, alpha: 1) }
        if( sender.tag == 5){ sender.backgroundColor = UIColor.black }
    }
    

    @IBAction func Solution(_ sender: UIButton) {
        sender.isHidden = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            perdu = true
            self.performSegue(withIdentifier: "quitter", sender: self)
        }
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}
