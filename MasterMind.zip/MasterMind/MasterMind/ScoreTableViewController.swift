import UIKit

class ScoreTableViewController: UITableViewController {
    
    var scoring = ["1er : ", "2eme : ", "3eme : ","Retour"]

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cellule", for: indexPath)
        
        scoring[0] = "1er : " + String(classement[0]) + " ( " + userData.string(forKey: "nc0")! + " ) "
        scoring[1] = "2eme : " + String(classement[1]) + " ( " + userData.string(forKey: "nc1")! + " ) "
        scoring[2] = "3eme : " + String(classement[2]) + " ( " + userData.string(forKey: "nc2")! + " ) "
        
        if(userData.string(forKey: "nc0") == nil || userData.string(forKey: "nc0") == "") {
            userData.set("",forKey: "nc0")
            scoring[0] = "1er : " + String(classement[0])
        }
        if(userData.string(forKey: "nc1") == nil || userData.string(forKey: "nc1") == "") {
            userData.set("",forKey: "nc1")
            scoring[1] = "2eme : " + String(classement[1])
        }
        if(userData.string(forKey: "nc2") == nil || userData.string(forKey: "nc2") == "") {
            userData.set("",forKey: "nc2")
            scoring[2] = "3eme : " + String(classement[2])
        }
        
       
        cell.textLabel?.text = scoring[indexPath.row]
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if(indexPath.row == 3){
            performSegue(withIdentifier: "segue", sender: self)
        }
    }
    
}

