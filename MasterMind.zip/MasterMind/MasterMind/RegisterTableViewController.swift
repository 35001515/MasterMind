import UIKit


var monIndex = 0

class RegisterTableViewController: UITableViewController {

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CelluleEnreg", for: indexPath)
        
        if(userData.string(forKey: "n1") == nil){ userData.set("Sauvegarde 1 :",forKey: "n1") }
        if(userData.string(forKey: "n2") == nil){ userData.set("Sauvegarde 2 :",forKey: "n2") }
        if(userData.string(forKey: "n3") == nil){ userData.set("Sauvegarde 3 :",forKey: "n3") }
        
        if(userData.string(forKey: "t1") == nil){ userData.set("",forKey: "t1") }
        if(userData.string(forKey: "t2") == nil){ userData.set("",forKey: "t2") }
        if(userData.string(forKey: "t3") == nil){ userData.set("",forKey: "t3") }
        
        if(userData.string(forKey: "t1") == ""){
            save[0] = userData.string(forKey: "n1")!+" ( SCORE : " + String(userData.integer(forKey: "s1")) + " )"
        }
        else{
            save[0] = userData.string(forKey: "n1")!+" ( SCORE : " + String(userData.integer(forKey: "s1")) + " , le : "+userData.string(forKey: "t1")! + " )"
        }
        
        if(userData.string(forKey: "t2") == ""){
            save[1] = userData.string(forKey: "n2")!+" ( SCORE : " + String(userData.integer(forKey: "s2")) + " )"
        }
        else {
            save[1] = userData.string(forKey: "n2")!+" ( SCORE : " + String(userData.integer(forKey: "s2")) + " , le : "+userData.string(forKey: "t2")! + " )"
        }
        
        if(userData.string(forKey: "t3") == ""){
            save[2] = userData.string(forKey: "n3")!+" ( SCORE : " + String(userData.integer(forKey: "s3")) + " )"
        }
        else {
            save[2] = userData.string(forKey: "n3")!+" ( SCORE : " + String(userData.integer(forKey: "s3")) + " , le : "+userData.string(forKey: "t3")! + " )"
        }
        
        cell.textLabel?.text = save[indexPath.row]
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        monIndex = indexPath.row
        if(monIndex == 3){
            performSegue(withIdentifier: "quittermenu", sender: self)
        }
        else {
            performSegue(withIdentifier: "seguemenu", sender: self)
        }
        
    }

}
