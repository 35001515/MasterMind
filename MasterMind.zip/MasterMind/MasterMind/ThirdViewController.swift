import UIKit

class ThirdViewController: UIViewController {

    @IBOutlet weak var Perdu: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if(perdu) {
            Perdu.isHidden = false
        }
    }


    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
