import UIKit

class ChoiceViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

    @IBAction func Clean(_ sender: UIButton) {
        if(myIndex == 0){
            userData.set(0,forKey:"s1")
            userData.set(nil,forKey:"n1")
            userData.set("",forKey:"t1")
        }
        
        if(myIndex == 1){
            userData.set(0,forKey:"s2")
            userData.set(nil,forKey:"n2")
            userData.set("",forKey:"t2")
        }
        
        if(myIndex == 2){
            userData.set(0,forKey:"s3")
            userData.set(nil,forKey:"n3")
            userData.set("",forKey:"t3")
        }
    }

}
